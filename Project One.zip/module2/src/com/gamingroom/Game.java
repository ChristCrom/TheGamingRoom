package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires an id and name to be passed
 * when creating. Also note that no mutators (setters) defined so these values
 * cannot be changed once a game is created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {

	private List<Team> teams = new ArrayList<>();

	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		super(id, name);
	}

	public Team addTeam(String name) {
		// a local player instance
		Team team = null;

		/*
		 * Iterator Pattern Purpose and Characteristics The purpose of the iterator
		 * pattern is to be able to go through each element of a list. In this case, a
		 * for loop is being used basically saying, for each existingPlayer in the list
		 * players, execute the code inside the loop.
		 */
		// if found, simply return the existing instance
		for (int i = 0; i < teams.size(); i++) {
			if (teams.get(i).getName() == name) {
				team = teams.get(i);
			}
		}

		// if not found, make a new player instance and add to list of players
		if (team == null) {
			team = new Team(GameService.getInstance().getNextTeamId(), name);
			teams.add(team);
		}

		// return the new/existing player instance to the caller
		return team;
	}

	@Override
	public String toString() {

		return "Game [id=" + id + ", name=" + name + "]";
	}

}
