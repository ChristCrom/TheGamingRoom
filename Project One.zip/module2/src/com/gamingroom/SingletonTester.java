package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * @author coce@snhu.edu
 */
public class SingletonTester {

	public void testSingleton() {

		System.out.println("\nAbout to test the singleton...");

		/*
		 * replaced null with getInstance function so we make sure we don't create any
		 * new game instances and only get the one created earlier. If we used
		 * GameService service = new GameService,it would create another instance of the
		 * object in the memory rather than just using the one
		 */
		GameService service = GameService.getInstance();

		// a simple for loop to print the games
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}

	}

}
